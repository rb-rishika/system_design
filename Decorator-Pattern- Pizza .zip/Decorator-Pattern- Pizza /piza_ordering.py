from margherita import Margherita
from veggie_delight import VeggieDelight
from toppings import Cheese, Olives

pizza = Margherita()
print(pizza.get_description(), "$", pizza.get_cost())

# Add cheese
pizza = Cheese(pizza)
# Add olives
pizza = Olives(pizza)

print(pizza.get_description(), "$", pizza.get_cost())

pizzaNew = VeggieDelight()

pizzaNew=Olives(Cheese(pizzaNew))
print(pizzaNew.get_description(), "$", pizzaNew.get_cost())