from Pizza import Pizza
class VeggieDelight(Pizza):
    def get_description(self) -> str:
        return "VeggieDelight"

    def get_cost(self) -> float:
        return 6.00