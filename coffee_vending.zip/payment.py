class Payment:
    def __init__(self, amount):
        self.amount = amount

    def get_amount(self):
        return self.amount